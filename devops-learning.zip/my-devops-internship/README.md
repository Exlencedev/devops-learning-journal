# 🖥️ DevOps Öğrenme Günlüğü

Bu repo, Linux ve DevOps temellerini öğrenirken tuttuğum günlük notlardan oluşuyor. [alifurkan-altuntas/devops-internship](https://github.com/alifurkan-altuntas/devops-internship) reposundaki müfredatı takip ederek, VirtualBox üzerinde kurduğum Rocky Linux VM'inde adım adım ilerliyorum.

Her faz, sadece komutları değil, karşılaştığım gerçek hataları ve onları nasıl çözdüğümü de içeriyor.

---

## 📅 İlerleme

| # | Faz | Durum | Tarih |
|---|-----|-------|-------|
| 00 | VM Kurulumu (VirtualBox + Rocky Linux 10.2) | ✅ Tamamlandı | Gün 1 |
| 01 | Linux Temelleri (hostname, grep/cut/awk) | ✅ Tamamlandı | Gün 2 |
| 02 | Dosya Sistemi Yönetimi (dd, du, df, find) | ✅ Tamamlandı | Gün 2 |
| 03 | Kullanıcı & Yetki Yönetimi (sudo, visudo) | 🔜 Sırada | - |

---

## 🛠️ Ortam

- **Hypervisor:** VirtualBox 7.2.14
- **Guest OS:** Rocky Linux 10.2 (Red Quartz)
- **VM Kaynakları:** 4096 MB RAM, 4 vCPU, 20 GB Disk
- **Klavye Düzeni:** Türkçe (TR)

---

## 📚 Kaynak

Bu öğrenme yolculuğu [alifurkan-altuntas/devops-internship](https://github.com/alifurkan-altuntas/devops-internship) reposundaki müfredat sırası takip edilerek hazırlanmıştır.
